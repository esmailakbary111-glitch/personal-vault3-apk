# ساخت APK فقط با گوشی — Personal Vault

این بسته برای حالتی آماده شده که کامپیوتر نداری و می‌خواهی APK را با GitHub Actions بسازی.

## کاری که باید انجام بدهی

1. یک Repository خالی در GitHub بساز.
2. تمام محتویات این پوشه را داخل Repository آپلود کن. فایل `.github/workflows/build-apk.yml` را هم حتماً نگه دار.
3. وارد بخش `Actions` همان Repository شو.
4. Workflow با نام `Build Personal Vault APK` را باز کن.
5. گزینهٔ `Run workflow` را بزن.
6. بعد از پایان موفق Build، وارد همان اجرای Workflow شو.
7. در بخش `Artifacts` فایل `personal-vault-apk` را دانلود کن.
8. فایل دانلودشده را باز کن؛ داخل آن `app-debug.apk` قرار دارد.
9. `app-debug.apk` را روی گوشی نصب کن.

## چرا این روش کار می‌کند؟

Workflow به‌صورت خودکار JDK 17، Android SDK، Build Tools 36.0.0 و Gradle 9.6.0 را آماده می‌کند و سپس پروژهٔ Android را Build می‌کند.

## نکته

این APK نسخهٔ Debug است و برای نصب شخصی و تست مناسب است. برای انتشار عمومی در فروشگاه، باید نسخهٔ Release امضاشده با کلید اختصاصی ساخته شود.
