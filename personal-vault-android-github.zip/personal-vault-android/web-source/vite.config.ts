import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { crx } from '@crxjs/vite-plugin';
import manifest from './manifest.json';

export default defineConfig({
  plugins: [react(), crx({ manifest: manifest as any })],
  build: {
    target: 'es2022',
    sourcemap: false,
    rollupOptions: {
      output: { chunkFileNames: 'assets/chunk-[hash].js' },
    },
  },
  server: { port: 5173, strictPort: true, hmr: { port: 5173 } },
});
