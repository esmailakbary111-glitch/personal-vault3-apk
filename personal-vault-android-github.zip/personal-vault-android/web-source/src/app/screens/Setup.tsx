import { useState } from 'react';
import { useVault } from '../../state/vault';
import { Button, Field, Input } from '../../ui/primitives';
import { IconEye, IconEyeOff, IconLock } from '../../ui/icons';
import { toast } from '../../state/ui';

function strengthOf(pw: string): number {
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return Math.min(score, 4);
}

export function Setup() {
  const setup = useVault((s) => s.setup);
  const [pw, setPw] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const score = strengthOf(pw);
  const scoreClass = score <= 2 ? 'on-weak' : score === 3 ? 'on-ok' : 'on-strong';

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (pw.length < 8) return setError('Password must be at least 8 characters.');
    if (pw.length > 15) return setError('Password must be at most 15 characters.');
    if (pw !== confirm) return setError('Passwords do not match.');
    setBusy(true);
    try {
      await setup(pw);
      toast('Vault created successfully', 'success');
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  }

  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={onSubmit}>
        <div className="auth-lock-icon"><IconLock width={22} height={22} /></div>
        <h1 className="auth-title">Create your vault</h1>
        <p className="auth-desc">
          Your password protects everything. It is never stored anywhere and
          <strong> cannot be recovered</strong> if you forget it.
        </p>

        <Field label="Password" hint="8 to 15 characters." htmlFor="pw">
          <div className="pw-wrap">
            <Input
              id="pw"
              type={show ? 'text' : 'password'}
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              autoFocus
              maxLength={15}
              autoComplete="new-password"
            />
            <button
              type="button"
              className="icon-btn pw-toggle"
              onClick={() => setShow((s) => !s)}
              aria-label={show ? 'Hide password' : 'Show password'}
            >
              {show ? <IconEyeOff /> : <IconEye />}
            </button>
          </div>
          <div className="strength" aria-hidden>
            {[0, 1, 2, 3].map((i) => (
              <span key={i} className={i < score ? scoreClass : ''} />
            ))}
          </div>
        </Field>

        <Field label="Confirm password" htmlFor="pw2">
          <Input
            id="pw2"
            type={show ? 'text' : 'password'}
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            maxLength={15}
            autoComplete="new-password"
          />
        </Field>

        {error && <div className="field-error" role="alert" style={{ marginBottom: 12 }}>{error}</div>}

        <Button type="submit" variant="primary" loading={busy} style={{ width: '100%' }}>
          Create vault
        </Button>
      </form>
    </div>
  );
}
