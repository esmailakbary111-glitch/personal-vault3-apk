import { useEffect, useMemo, useRef, useState } from 'react';
import { useVault } from '../../state/vault';
import { useCounts } from '../../state/items';
import { toast } from '../../state/ui';
import {
  createItem, listItems, readBlobPlain, softDeleteItem, updateItemPayload,
} from '../../core/repos';
import type { ItemPayload, ItemRecord, ItemType } from '../../core/types';
import { downloadBlob, formatBytes, formatDate, sanitizeForFilename } from '../../core/utils';
import { Button, EmptyState, Field, Input, Textarea } from '../../ui/primitives';
import { Modal, ConfirmDialog } from '../../ui/Modal';
import {
  IconDownload, IconEdit, IconCopy, IconOpen, IconPlus, IconSearch, IconTrash, IconClose,
  IconImage, IconText, IconFolder,
} from '../../ui/icons';

type SortKey = 'newest' | 'oldest' | 'name';
interface Row { record: ItemRecord; payload: ItemPayload; }

export function ItemsScreen({ type }: { type: ItemType }) {
  const dek = useVault((s) => s.dek)!;
  const refreshCounts = useCounts((s) => s.refresh);
  const [allRows, setAllRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<SortKey>('newest');
  const [addOpen, setAddOpen] = useState(false);
  const [viewItem, setViewItem] = useState<Row | null>(null);
  const [editItem, setEditItem] = useState<Row | null>(null);
  const [deleteItem, setDeleteItem] = useState<Row | null>(null);
  const [busyDelete, setBusyDelete] = useState(false);

  async function refresh() {
    setLoading(true);
    try {
      const r = await listItems({ type, dek, sort: 'newest' });
      setAllRows(r);
    } finally { setLoading(false); }
    refreshCounts();
  }

  useEffect(() => {
    if (!dek) return;
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const r = await listItems({ type, dek, sort: 'newest' });
        if (active) setAllRows(r);
      } finally { if (active) setLoading(false); }
    })();
    return () => { active = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, dek]);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = q
      ? allRows.filter((r) => r.payload.displayName.toLowerCase().includes(q))
      : allRows.slice();
    filtered.sort((a, b) => {
      if (sort === 'newest') return b.record.updatedAt - a.record.updatedAt;
      if (sort === 'oldest') return a.record.updatedAt - b.record.updatedAt;
      return a.payload.displayName.localeCompare(b.payload.displayName, undefined, { sensitivity: 'base' });
    });
    return filtered;
  }, [allRows, search, sort]);

  const title = type === 'file' ? 'Files' : type === 'image' ? 'Images' : 'Texts';
  const icon = type === 'file' ? <IconFolder width={28} height={28}/> : type === 'image' ? <IconImage width={28} height={28}/> : <IconText width={28} height={28}/>;

  return (
    <div className="container">
      <div className="toolbar">
        <div className="search">
          <span className="search-icon"><IconSearch /></span>
          <input
            className="input"
            placeholder={`Search ${title.toLowerCase()}…`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label={`Search ${title}`}
          />
        </div>
        <select className="select" value={sort} onChange={(e) => setSort(e.target.value as SortKey)} aria-label="Sort">
          <option value="newest">Newest</option>
          <option value="oldest">Oldest</option>
          <option value="name">Name A–Z</option>
        </select>
        <Button variant="primary" icon={<IconPlus />} onClick={() => setAddOpen(true)}>
          Add {type === 'file' ? 'file' : type === 'image' ? 'image' : 'text'}
        </Button>
      </div>

      {loading ? (
        <div className="empty"><span className="spinner" /></div>
      ) : rows.length === 0 ? (
        <EmptyState
          icon={icon}
          title={search ? 'No matches' : `No ${title.toLowerCase()} yet`}
          description={search ? 'Try a different search.' : `Add your first ${type}.`}
          action={!search && <Button variant="primary" icon={<IconPlus />} onClick={() => setAddOpen(true)}>Add</Button>}
        />
      ) : type === 'image' ? (
        <GalleryView rows={rows} dek={dek} onOpen={setViewItem} onDelete={setDeleteItem} onRename={setEditItem} />
      ) : (
        <ListView rows={rows} type={type} dek={dek} onOpen={setViewItem} onDelete={setDeleteItem} onEdit={setEditItem} />
      )}

      <AddModal open={addOpen} type={type} dek={dek} onClose={() => setAddOpen(false)} onAdded={() => { setAddOpen(false); refresh(); }} />

      {viewItem && type !== 'text' && (
        <Lightbox row={viewItem} dek={dek} onClose={() => setViewItem(null)} />
      )}

      {viewItem && type === 'text' && (
        <ReaderModal row={viewItem} onClose={() => setViewItem(null)} onEdit={() => { setEditItem(viewItem); setViewItem(null); }} />
      )}

      {editItem && (
        <EditModal row={editItem} dek={dek} isText={type === 'text'} onClose={() => setEditItem(null)} onSaved={() => { setEditItem(null); refresh(); }} />
      )}

      <ConfirmDialog
        open={!!deleteItem}
        title="Move to Trash?"
        message={deleteItem ? `"${deleteItem.payload.displayName}" will be moved to Trash. You can restore it later.` : ''}
        confirmLabel="Move to Trash"
        danger
        busy={busyDelete}
        onCancel={() => setDeleteItem(null)}
        onConfirm={async () => {
          if (!deleteItem) return;
          setBusyDelete(true);
          try {
            await softDeleteItem(deleteItem.record.id);
            toast('Moved to Trash', 'success');
            setDeleteItem(null);
            refresh();
          } catch (e) { toast((e as Error).message, 'error'); }
          finally { setBusyDelete(false); }
        }}
      />
    </div>
  );
}

function ListView({ rows, type, dek, onOpen, onDelete, onEdit }: {
  rows: Row[]; type: ItemType; dek: CryptoKey;
  onOpen: (r: Row) => void; onDelete: (r: Row) => void; onEdit: (r: Row) => void;
}) {
  return (
    <div className="item-list" role="list">
      {rows.map((r) => (
        <div key={r.record.id} className="item-row" role="listitem">
          <div style={{ width: 32, height: 32, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: 'var(--surface)', borderRadius: 8, color: 'var(--accent)' }}>
            {type === 'file' ? <IconFolder /> : <IconText />}
          </div>
          <div className="item-info">
            <div className="item-name" title={r.payload.displayName}>{r.payload.displayName}</div>
            <div className="item-meta">
              {type === 'file' && <span>{formatBytes(r.record.size)}</span>}
              <span>{formatDate(r.record.updatedAt)}</span>
            </div>
            {type === 'text' && r.payload.textContent && (
              <div className="text-preview">{r.payload.textContent}</div>
            )}
          </div>
          <div className="item-actions">
            <Button size="sm" variant="ghost" icon={<IconOpen />} onClick={() => onOpen(r)} aria-label="Open">Open</Button>
            {type === 'file' && <FileDownloadButton row={r} dek={dek} />}
            {type === 'text' && <TextCopyButton row={r} />}
            <Button size="sm" variant="ghost" icon={<IconEdit />} onClick={() => onEdit(r)} aria-label="Rename or edit">Edit</Button>
            <Button size="sm" variant="ghost" icon={<IconTrash />} onClick={() => onDelete(r)} aria-label="Delete" />
          </div>
        </div>
      ))}
    </div>
  );
}

function GalleryView({ rows, dek, onOpen, onDelete, onRename }: {
  rows: Row[]; dek: CryptoKey;
  onOpen: (r: Row) => void; onDelete: (r: Row) => void; onRename: (r: Row) => void;
}) {
  return (
    <div className="gallery">
      {rows.map((r) => (
        <GalleryCard key={r.record.id} row={r} dek={dek} onOpen={onOpen} onDelete={onDelete} onRename={onRename} />
      ))}
    </div>
  );
}

function GalleryCard({ row, dek, onOpen, onDelete, onRename }:
  { row: Row; dek: CryptoKey; onOpen: (r: Row) => void; onDelete: (r: Row) => void; onRename: (r: Row) => void }) {
  const [url, setUrl] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let active = true;
    let created: string | null = null;
    const el = containerRef.current;
    if (!el || !row.record.blobId) return;

    const observer = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (e.isIntersecting) {
          readBlobPlain(row.record.blobId!, dek).then((buf) => {
            if (!active) return;
            const blob = new Blob([buf], { type: row.record.mimeType });
            created = URL.createObjectURL(blob);
            setUrl(created);
          }).catch(() => { /* ignore */ });
          observer.disconnect();
        }
      }
    }, { rootMargin: '200px' });
    observer.observe(el);

    return () => {
      active = false;
      observer.disconnect();
      if (created) URL.revokeObjectURL(created);
    };
  }, [row.record.blobId, row.record.mimeType, dek]);

  return (
    <div ref={containerRef} className="gallery-card" tabIndex={0} role="button"
      onClick={() => onOpen(row)}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpen(row); } }}
      aria-label={`Open ${row.payload.displayName}`}
    >
      <div className="gallery-thumb">
        {url ? <img src={url} alt="" /> : <span className="spinner" />}
      </div>
      <div className="gallery-caption">
        <div className="gallery-name" title={row.payload.displayName}>{row.payload.displayName}</div>
        <div className="item-meta"><span>{formatBytes(row.record.size)}</span></div>
      </div>
      <div className="gallery-tools">
        <button className="icon-btn" onClick={(e) => { e.stopPropagation(); onRename(row); }} aria-label="Rename"><IconEdit width={14} height={14} /></button>
        <button className="icon-btn" onClick={(e) => { e.stopPropagation(); onDelete(row); }} aria-label="Delete"><IconTrash width={14} height={14} /></button>
      </div>
    </div>
  );
}

function AddModal({ open, type, dek, onClose, onAdded }:
  { open: boolean; type: ItemType; dek: CryptoKey; onClose: () => void; onAdded: () => void }) {
  const [displayName, setDisplayName] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [textTitle, setTextTitle] = useState('');
  const [textBody, setTextBody] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) {
      setDisplayName(''); setFile(null); setTextTitle(''); setTextBody('');
      setBusy(false); setError(null);
    }
  }, [open]);

  async function onPickFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0] ?? null;
    setFile(f);
    if (f && !displayName) setDisplayName(f.name);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (busy) return;
    if (type === 'text') {
      const title = textTitle.trim();
      if (!title) { setError('Title is required for text items.'); return; }
      setBusy(true);
      try {
        await createItem({
          type: 'text', mimeType: 'text/plain', size: new Blob([textBody]).size,
          payload: { displayName: title, textContent: textBody }, dek,
        });
        toast('Text added', 'success');
        onAdded();
      } catch (err) { setError((err as Error).message); setBusy(false); }
      return;
    }
    if (!file) { setError('Please choose a file.'); return; }
    setBusy(true);
    try {
      const buf = await file.arrayBuffer();
      const name = (displayName || file.name).trim() || file.name;
      await createItem({
        type, mimeType: file.type || 'application/octet-stream', size: file.size,
        payload: { displayName: name }, blobPlain: buf, dek,
      });
      toast(type === 'image' ? 'Image added' : 'File added', 'success');
      onAdded();
    } catch (err) { setError((err as Error).message); setBusy(false); }
  }

  return (
    <Modal
      open={open} onClose={onClose}
      title={type === 'text' ? 'Add text' : type === 'image' ? 'Add image' : 'Add file'}
      footer={<>
        <Button variant="ghost" onClick={onClose} disabled={busy}>Cancel</Button>
        <Button variant="primary" onClick={submit} loading={busy}>Add</Button>
      </>}
    >
      <form onSubmit={submit}>
        {type === 'text' ? (
          <>
            <Field label="Title" htmlFor="t-title">
              <Input id="t-title" value={textTitle} onChange={(e) => setTextTitle(e.target.value)} autoFocus maxLength={200} />
            </Field>
            <Field label="Content" htmlFor="t-body">
              <Textarea id="t-body" value={textBody} onChange={(e) => setTextBody(e.target.value)} rows={10} />
            </Field>
          </>
        ) : (
          <>
            <Field label={type === 'image' ? 'Image file' : 'File'}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <Button type="button" onClick={() => fileInputRef.current?.click()}>
                  {file ? 'Change file' : 'Choose file'}
                </Button>
                <span style={{ color: 'var(--fg-muted)', fontSize: 13, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {file ? `${file.name} • ${formatBytes(file.size)}` : 'No file chosen'}
                </span>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept={type === 'image' ? 'image/*' : undefined}
                onChange={onPickFile}
                style={{ display: 'none' }}
              />
            </Field>
            <Field label="Display name (optional)" htmlFor="d-name">
              <Input id="d-name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} maxLength={200}
                placeholder={file?.name ?? 'Leave empty to use filename'} />
            </Field>
          </>
        )}
        {error && <div className="field-error" role="alert">{error}</div>}
      </form>
    </Modal>
  );
}

function EditModal({ row, dek, isText, onClose, onSaved }:
  { row: Row; dek: CryptoKey; isText: boolean; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState(row.payload.displayName);
  const [body, setBody] = useState(row.payload.textContent ?? '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [discardOpen, setDiscardOpen] = useState(false);

  const originalName = row.payload.displayName;
  const originalBody = row.payload.textContent ?? '';
  const dirty = name !== originalName || (isText && body !== originalBody);

  async function save() {
    if (busy) return;
    setError(null);
    const patch: Partial<ItemPayload> = { displayName: name.trim() || originalName };
    if (isText) patch.textContent = body;
    setBusy(true);
    try {
      await updateItemPayload(row.record.id, patch, dek);
      toast('Saved', 'success');
      onSaved();
    } catch (e) { setError((e as Error).message); setBusy(false); }
  }

  function tryClose() {
    if (dirty) { setDiscardOpen(true); return; }
    onClose();
  }

  return (
    <>
      <Modal open onClose={tryClose} title={isText ? 'Edit text' : 'Rename'}
        footer={<>
          <Button variant="ghost" onClick={tryClose} disabled={busy}>Cancel</Button>
          <Button variant="primary" onClick={save} loading={busy} disabled={!dirty}>Save</Button>
        </>}
      >
        <Field label="Display name" htmlFor="e-name">
          <Input id="e-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={200} autoFocus={!isText} />
        </Field>
        {isText && (
          <Field label="Content" htmlFor="e-body">
            <Textarea id="e-body" value={body} onChange={(e) => setBody(e.target.value)} rows={14} autoFocus />
          </Field>
        )}
        {error && <div className="field-error" role="alert">{error}</div>}
      </Modal>

      <ConfirmDialog
        open={discardOpen}
        title="Discard changes?"
        message="You have unsaved changes. If you leave now, they will be lost."
        confirmLabel="Discard"
        danger
        onCancel={() => setDiscardOpen(false)}
        onConfirm={() => { setDiscardOpen(false); onClose(); }}
      />
    </>
  );
}

function Lightbox({ row, dek, onClose }: { row: Row; dek: CryptoKey; onClose: () => void }) {
  const [url, setUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let created: string | null = null;
    let active = true;
    if (row.record.blobId) {
      readBlobPlain(row.record.blobId, dek)
        .then((buf) => {
          if (!active) return;
          created = URL.createObjectURL(new Blob([buf], { type: row.record.mimeType }));
          setUrl(created);
        })
        .catch((e) => setError((e as Error).message));
    }
    return () => { active = false; if (created) URL.revokeObjectURL(created); };
  }, [row, dek]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) { if (e.key === 'Escape') onClose(); }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="lightbox" role="dialog" aria-modal="true" aria-label={row.payload.displayName}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <button className="icon-btn lightbox-close" onClick={onClose} aria-label="Close">
        <IconClose />
      </button>
      {error ? <div style={{ color: 'white' }}>{error}</div>
        : url ? <img src={url} alt={row.payload.displayName} /> : <span className="spinner" />}
    </div>
  );
}

function ReaderModal({ row, onClose, onEdit }: { row: Row; onClose: () => void; onEdit: () => void }) {
  return (
    <Modal open onClose={onClose} title={row.payload.displayName} size="lg"
      footer={<>
        <Button variant="ghost" onClick={onClose}>Close</Button>
        <TextCopyButton row={row} />
        <Button variant="primary" icon={<IconEdit />} onClick={onEdit}>Edit</Button>
      </>}
    >
      <div className="reader-content">{row.payload.textContent ?? ''}</div>
    </Modal>
  );
}

function FileDownloadButton({ row, dek }: { row: Row; dek: CryptoKey }) {
  const [busy, setBusy] = useState(false);
  return (
    <Button size="sm" variant="ghost" icon={<IconDownload />} loading={busy}
      onClick={async () => {
        if (!row.record.blobId) return;
        setBusy(true);
        try {
          const buf = await readBlobPlain(row.record.blobId, dek);
          downloadBlob(buf, sanitizeForFilename(row.payload.displayName), row.record.mimeType);
        } catch (e) { toast((e as Error).message, 'error'); }
        finally { setBusy(false); }
      }} aria-label="Download" />
  );
}

function TextCopyButton({ row }: { row: Row }) {
  return (
    <Button size="sm" variant="ghost" icon={<IconCopy />}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(row.payload.textContent ?? '');
          toast('Copied', 'success');
        } catch (e) { toast('Copy failed: ' + (e as Error).message, 'error'); }
      }} aria-label="Copy">Copy</Button>
  );
}
