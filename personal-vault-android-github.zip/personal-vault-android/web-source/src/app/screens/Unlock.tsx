import { useState } from 'react';
import { useVault } from '../../state/vault';
import { Button, Field, Input } from '../../ui/primitives';
import { IconEye, IconEyeOff, IconLock } from '../../ui/icons';

export function Unlock() {
  const unlock = useVault((s) => s.unlock);
  const error = useVault((s) => s.error);
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!pw) return;
    setBusy(true);
    const ok = await unlock(pw);
    setBusy(false);
    if (!ok) setPw('');
  }

  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={onSubmit}>
        <div className="auth-lock-icon"><IconLock width={22} height={22} /></div>
        <h1 className="auth-title">Welcome back</h1>
        <p className="auth-desc">Enter your password to unlock the vault.</p>

        <Field label="Password" htmlFor="pw">
          <div className="pw-wrap">
            <Input
              id="pw"
              type={show ? 'text' : 'password'}
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              autoFocus
              maxLength={15}
              autoComplete="current-password"
            />
            <button
              type="button"
              className="icon-btn pw-toggle"
              onClick={() => setShow((s) => !s)}
              aria-label={show ? 'Hide password' : 'Show password'}
            >
              {show ? <IconEyeOff /> : <IconEye />}
            </button>
          </div>
        </Field>

        {error && <div className="field-error" role="alert" style={{ marginBottom: 12 }}>{error}</div>}

        <Button type="submit" variant="primary" loading={busy} disabled={!pw} style={{ width: '100%' }}>
          Unlock
        </Button>
      </form>
    </div>
  );
}
