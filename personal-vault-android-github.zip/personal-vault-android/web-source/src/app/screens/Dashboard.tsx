import { IconFolder, IconImage, IconText } from '../../ui/icons';
import type { ItemType } from '../../core/types';

interface Props {
  counts: { files: number; images: number; texts: number; trash: number };
  onOpen: (type: ItemType) => void;
}

export function Dashboard({ counts, onOpen }: Props) {
  return (
    <div className="container">
      <h1 style={{ fontSize: 22, marginTop: 0, marginBottom: 6, letterSpacing: '-0.02em' }}>Your vault</h1>
      <p style={{ color: 'var(--fg-muted)', marginTop: 0, marginBottom: 24 }}>
        Everything is encrypted and stored locally on this device.
      </p>

      <div className="dash-grid">
        <button className="card card-interactive dash-card" onClick={() => onOpen('file')} aria-label={`Files, ${counts.files} items`}>
          <div className="dash-icon"><IconFolder width={22} height={22} /></div>
          <div>
            <div className="dash-title">Files</div>
            <div className="dash-desc">Documents and any file type</div>
          </div>
          <div className="dash-count">{counts.files}</div>
        </button>

        <button className="card card-interactive dash-card" onClick={() => onOpen('image')} aria-label={`Images, ${counts.images} items`}>
          <div className="dash-icon"><IconImage width={22} height={22} /></div>
          <div>
            <div className="dash-title">Images</div>
            <div className="dash-desc">Photos with preview and gallery</div>
          </div>
          <div className="dash-count">{counts.images}</div>
        </button>

        <button className="card card-interactive dash-card" onClick={() => onOpen('text')} aria-label={`Texts, ${counts.texts} items`}>
          <div className="dash-icon"><IconText width={22} height={22} /></div>
          <div>
            <div className="dash-title">Texts</div>
            <div className="dash-desc">Notes, snippets and long-form text</div>
          </div>
          <div className="dash-count">{counts.texts}</div>
        </button>
      </div>
    </div>
  );
}
