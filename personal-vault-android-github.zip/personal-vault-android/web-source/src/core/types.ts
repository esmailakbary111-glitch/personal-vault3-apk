export type ItemType = 'file' | 'image' | 'text';

export interface ItemRecord {
  id: string;
  type: ItemType;
  size: number;
  mimeType: string;
  createdAt: number;
  updatedAt: number;
  /** 0 = active; timestamp = in trash */
  deletedAt: number;
  blobId: string | null;
  /** Encrypted JSON payload: { displayName, textContent?, imageMeta? } */
  payload: ArrayBuffer;
  payloadIv: ArrayBuffer;
}

export interface BlobRecord {
  id: string;
  iv: ArrayBuffer;
  data: ArrayBuffer;
  createdAt: number;
}

export interface ItemPayload {
  displayName: string;
  textContent?: string;
  imageMeta?: { width: number; height: number };
}

export interface KdfMeta {
  salt: string;
  iterations: number;
  hash: 'SHA-256';
}

export interface VerifierMeta {
  ciphertext: string;
  iv: string;
}

export interface WrappedDekMeta {
  wrapped: string;
  iv: string;
}

export interface VaultSettings {
  autoLockMinutes: number;
}
