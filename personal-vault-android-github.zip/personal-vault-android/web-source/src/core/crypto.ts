import { bufToB64, b64ToBuf } from './utils';
import type { KdfMeta, VerifierMeta, WrappedDekMeta } from './types';

const PBKDF2_ITERATIONS = 600_000;
const VERIFIER_STRING = 'VAULT_VERIFIER_OK_v1';

export async function deriveKEK(password: string, salt: ArrayBuffer): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    'raw', enc.encode(password), 'PBKDF2', false, ['deriveKey'],
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['wrapKey', 'unwrapKey', 'encrypt', 'decrypt'],
  );
}

export function randomSalt(): ArrayBuffer {
  return crypto.getRandomValues(new Uint8Array(16)).buffer;
}

export async function generateDEK(): Promise<CryptoKey> {
  return crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
}

export async function wrapDEK(dek: CryptoKey, kek: CryptoKey): Promise<WrappedDekMeta> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const wrapped = await crypto.subtle.wrapKey('raw', dek, kek, { name: 'AES-GCM', iv });
  return { wrapped: bufToB64(wrapped), iv: bufToB64(iv.buffer) };
}

export async function unwrapDEK(meta: WrappedDekMeta, kek: CryptoKey): Promise<CryptoKey> {
  return crypto.subtle.unwrapKey(
    'raw',
    b64ToBuf(meta.wrapped),
    kek,
    { name: 'AES-GCM', iv: b64ToBuf(meta.iv) },
    { name: 'AES-GCM', length: 256 },
    true,
    ['encrypt', 'decrypt'],
  );
}

export async function aesEncrypt(
  key: CryptoKey, plaintext: ArrayBuffer,
): Promise<{ ciphertext: ArrayBuffer; iv: ArrayBuffer }> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);
  return { ciphertext, iv: iv.buffer };
}

export async function aesDecrypt(
  key: CryptoKey, ciphertext: ArrayBuffer, iv: ArrayBuffer,
): Promise<ArrayBuffer> {
  return crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
}

export async function encryptJSON(key: CryptoKey, value: unknown): Promise<{ ciphertext: ArrayBuffer; iv: ArrayBuffer }> {
  const json = new TextEncoder().encode(JSON.stringify(value));
  return aesEncrypt(key, json.buffer as ArrayBuffer);
}

export async function decryptJSON<T>(key: CryptoKey, ciphertext: ArrayBuffer, iv: ArrayBuffer): Promise<T> {
  const plain = await aesDecrypt(key, ciphertext, iv);
  return JSON.parse(new TextDecoder().decode(plain)) as T;
}

export async function makeVerifier(kek: CryptoKey): Promise<VerifierMeta> {
  const { ciphertext, iv } = await aesEncrypt(kek, new TextEncoder().encode(VERIFIER_STRING).buffer as ArrayBuffer);
  return { ciphertext: bufToB64(ciphertext), iv: bufToB64(iv) };
}

export async function checkVerifier(kek: CryptoKey, v: VerifierMeta): Promise<boolean> {
  try {
    const plain = await aesDecrypt(kek, b64ToBuf(v.ciphertext), b64ToBuf(v.iv));
    return new TextDecoder().decode(plain) === VERIFIER_STRING;
  } catch {
    return false;
  }
}

export function makeKdfMeta(salt: ArrayBuffer): KdfMeta {
  return { salt: bufToB64(salt), iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' };
}

export function kdfSalt(k: KdfMeta): ArrayBuffer {
  return b64ToBuf(k.salt);
}
