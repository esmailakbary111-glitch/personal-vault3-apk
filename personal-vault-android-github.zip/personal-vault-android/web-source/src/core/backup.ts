import { zipSync, unzipSync, strToU8, strFromU8 } from 'fflate';
import { checkVerifier, deriveKEK, kdfSalt, unwrapDEK, aesDecrypt } from './crypto';
import { bufToB64, b64ToBuf, uuid } from './utils';
import { getDB } from './db';
import type {
  ItemRecord, BlobRecord, KdfMeta, VerifierMeta, WrappedDekMeta,
} from './types';

interface BackupManifest {
  format: 'personal-vault';
  schemaVersion: number;
  appVersion: string;
  createdAt: number;
  counts: { files: number; images: number; texts: number; trash: number };
  kdf: KdfMeta;
  verifier: VerifierMeta;
  wrappedDek: WrappedDekMeta;
}

interface BackupItem extends Omit<ItemRecord, 'payload' | 'payloadIv'> {
  payloadB64: string;
  payloadIvB64: string;
}

interface BackupBlob {
  id: string;
  ivB64: string;
  dataB64: string;
  createdAt: number;
}

const BACKUP_FORMAT_VERSION = 1;
const APP_VERSION = '1.0.0';

export async function exportBackup(): Promise<Uint8Array> {
  const db = await getDB();
  const [kdf, verifier, wrappedDek] = await Promise.all([
    db.get('meta', 'kdf'),
    db.get('meta', 'verifier'),
    db.get('meta', 'wrappedDek'),
  ]);
  if (!kdf || !verifier || !wrappedDek) throw new Error('Vault not initialized');

  const items = await db.getAll('items');
  const blobs = await db.getAll('blobs');

  const manifest: BackupManifest = {
    format: 'personal-vault',
    schemaVersion: BACKUP_FORMAT_VERSION,
    appVersion: APP_VERSION,
    createdAt: Date.now(),
    counts: {
      files:  items.filter((i) => i.type === 'file'  && i.deletedAt === 0).length,
      images: items.filter((i) => i.type === 'image' && i.deletedAt === 0).length,
      texts:  items.filter((i) => i.type === 'text'  && i.deletedAt === 0).length,
      trash:  items.filter((i) => i.deletedAt !== 0).length,
    },
    kdf:       kdf.value as KdfMeta,
    verifier:  verifier.value as VerifierMeta,
    wrappedDek: wrappedDek.value as WrappedDekMeta,
  };

  const itemsJson: BackupItem[] = items.map((it) => ({
    ...it,
    payloadB64:   bufToB64(it.payload),
    payloadIvB64: bufToB64(it.payloadIv),
  }));

  const blobsJson: BackupBlob[] = blobs.map((b) => ({
    id: b.id,
    ivB64:   bufToB64(b.iv),
    dataB64: bufToB64(b.data),
    createdAt: b.createdAt,
  }));

  const files: Record<string, Uint8Array> = {
    'manifest.json': strToU8(JSON.stringify(manifest, null, 2)),
    'items.json':    strToU8(JSON.stringify(itemsJson)),
    'blobs.json':    strToU8(JSON.stringify(blobsJson)),
  };

  return zipSync(files, { level: 6 });
}

export interface ImportResult {
  dek: CryptoKey;
  kdf: KdfMeta;
  verifier: VerifierMeta;
  wrappedDek: WrappedDekMeta;
  itemCount: number;
  blobCount: number;
}

export async function importBackup(
  data: Uint8Array,
  backupPassword: string,
): Promise<ImportResult> {
  let unzipped: Record<string, Uint8Array>;
  try {
    unzipped = unzipSync(data);
  } catch {
    throw new Error('Invalid backup file: not a valid ZIP archive.');
  }

  if (!unzipped['manifest.json'] || !unzipped['items.json'] || !unzipped['blobs.json']) {
    throw new Error('Backup is incomplete: required files missing.');
  }

  let manifest: BackupManifest;
  try {
    manifest = JSON.parse(strFromU8(unzipped['manifest.json']));
  } catch {
    throw new Error('Backup manifest is corrupted.');
  }

  if (manifest.format !== 'personal-vault') {
    throw new Error('Unknown backup format.');
  }
  if (manifest.schemaVersion > BACKUP_FORMAT_VERSION) {
    throw new Error(
      `Backup was created by a newer version (schema ${manifest.schemaVersion}). ` +
      `This version only supports up to schema ${BACKUP_FORMAT_VERSION}.`,
    );
  }
  if (!manifest.kdf || !manifest.verifier || !manifest.wrappedDek) {
    throw new Error('Backup is missing encryption metadata.');
  }

  let itemsJson: BackupItem[];
  let blobsJson: BackupBlob[];
  try {
    itemsJson = JSON.parse(strFromU8(unzipped['items.json']));
    blobsJson = JSON.parse(strFromU8(unzipped['blobs.json']));
  } catch {
    throw new Error('Backup data files are corrupted.');
  }
  if (!Array.isArray(itemsJson) || !Array.isArray(blobsJson)) {
    throw new Error('Backup data files have unexpected structure.');
  }

  const blobIds = new Set(blobsJson.map((b) => b.id));
  for (const it of itemsJson) {
    if (it.blobId && !blobIds.has(it.blobId)) {
      throw new Error(`Backup integrity error: item "${it.id}" references a missing blob.`);
    }
  }

  const backupKek = await deriveKEK(backupPassword, kdfSalt(manifest.kdf));
  const okVerifier = await checkVerifier(backupKek, manifest.verifier);
  if (!okVerifier) {
    throw new Error('Wrong backup password.');
  }
  const backupDek = await unwrapDEK(manifest.wrappedDek, backupKek);

  if (itemsJson.length > 0) {
    try {
      await aesDecrypt(
        backupDek,
        b64ToBuf(itemsJson[0].payloadB64),
        b64ToBuf(itemsJson[0].payloadIvB64),
      );
    } catch {
      throw new Error('Backup payload cannot be decrypted. The backup may be corrupted.');
    }
  }

  const db = await getDB();
  const tx = db.transaction(['items', 'blobs', 'meta'], 'readwrite');
  try {
    await tx.objectStore('items').clear();
    await tx.objectStore('blobs').clear();
    await tx.objectStore('meta').clear();

    for (const b of blobsJson) {
      const rec: BlobRecord = {
        id: b.id,
        iv: b64ToBuf(b.ivB64),
        data: b64ToBuf(b.dataB64),
        createdAt: b.createdAt,
      };
      await tx.objectStore('blobs').put(rec);
    }

    for (const it of itemsJson) {
      const rec: ItemRecord = {
        id: it.id || uuid(),
        type: it.type,
        size: it.size,
        mimeType: it.mimeType,
        createdAt: it.createdAt,
        updatedAt: it.updatedAt,
        deletedAt: it.deletedAt ?? 0,
        blobId: it.blobId,
        payload:   b64ToBuf(it.payloadB64),
        payloadIv: b64ToBuf(it.payloadIvB64),
      };
      await tx.objectStore('items').put(rec);
    }

    await tx.objectStore('meta').put({ key: 'kdf',        value: manifest.kdf });
    await tx.objectStore('meta').put({ key: 'verifier',   value: manifest.verifier });
    await tx.objectStore('meta').put({ key: 'wrappedDek', value: manifest.wrappedDek });

    await tx.done;
  } catch (err) {
    try { tx.abort(); } catch { /* already aborted */ }
    throw new Error('Import failed, database left unchanged: ' + (err as Error).message);
  }

  return {
    dek: backupDek,
    kdf: manifest.kdf,
    verifier: manifest.verifier,
    wrappedDek: manifest.wrappedDek,
    itemCount: itemsJson.length,
    blobCount: blobsJson.length,
  };
}

export { BACKUP_FORMAT_VERSION, APP_VERSION };
