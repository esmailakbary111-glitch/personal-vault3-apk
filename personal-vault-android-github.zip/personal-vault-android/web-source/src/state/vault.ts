import { create } from 'zustand';
import {
  checkVerifier, deriveKEK, generateDEK, kdfSalt, makeKdfMeta, makeVerifier,
  unwrapDEK, wrapDEK,
} from '../core/crypto';
import { metaGet, metaSet, wipeAll } from '../core/repos';
import { exportBackup as doExport, importBackup as doImport } from '../core/backup';
import type { KdfMeta, VerifierMeta, WrappedDekMeta } from '../core/types';

export type VaultStatus = 'loading' | 'uninitialized' | 'locked' | 'unlocked';

interface VaultState {
  status: VaultStatus;
  dek: CryptoKey | null;
  error: string | null;
  kdf: KdfMeta | null;
  verifier: VerifierMeta | null;
  wrappedDek: WrappedDekMeta | null;

  init: () => Promise<void>;
  setup: (password: string) => Promise<void>;
  unlock: (password: string) => Promise<boolean>;
  lock: () => void;
  changePassword: (currentPassword: string, newPassword: string) => Promise<boolean>;
  destroy: () => Promise<void>;
  exportBackup: () => Promise<Uint8Array>;
  importBackup: (data: Uint8Array, backupPassword: string) => Promise<void>;
}

export const useVault = create<VaultState>((set, get) => ({
  status: 'loading',
  dek: null,
  error: null,
  kdf: null,
  verifier: null,
  wrappedDek: null,

  init: async () => {
    set({ status: 'loading', error: null });
    const kdf = await metaGet<KdfMeta>('kdf');
    const verifier = await metaGet<VerifierMeta>('verifier');
    const wrappedDek = await metaGet<WrappedDekMeta>('wrappedDek');
    if (!kdf || !verifier || !wrappedDek) {
      set({ status: 'uninitialized', kdf: null, verifier: null, wrappedDek: null });
    } else {
      set({ status: 'locked', kdf, verifier, wrappedDek });
    }
  },

  setup: async (password) => {
    const salt = crypto.getRandomValues(new Uint8Array(16)).buffer as ArrayBuffer;
    const kdf = makeKdfMeta(salt);
    const kek = await deriveKEK(password, salt);
    const dek = await generateDEK();
    const wrapped = await wrapDEK(dek, kek);
    const verifier = await makeVerifier(kek);

    await metaSet('kdf', kdf);
    await metaSet('verifier', verifier);
    await metaSet('wrappedDek', wrapped);

    set({ status: 'unlocked', dek, kdf, verifier, wrappedDek: wrapped, error: null });
  },

  unlock: async (password) => {
    const { kdf, verifier, wrappedDek } = get();
    if (!kdf || !verifier || !wrappedDek) return false;
    set({ error: null });
    const kek = await deriveKEK(password, kdfSalt(kdf));
    const ok = await checkVerifier(kek, verifier);
    if (!ok) {
      set({ error: 'Incorrect password' });
      return false;
    }
    const dek = await unwrapDEK(wrappedDek, kek);
    set({ status: 'unlocked', dek });
    return true;
  },

  lock: () => {
    set({ status: 'locked', dek: null });
  },

  changePassword: async (currentPassword, newPassword) => {
    const { kdf, verifier, wrappedDek, dek } = get();
    if (!kdf || !verifier || !wrappedDek || !dek) return false;
    const oldKek = await deriveKEK(currentPassword, kdfSalt(kdf));
    const ok = await checkVerifier(oldKek, verifier);
    if (!ok) {
      set({ error: 'Current password is incorrect' });
      return false;
    }
    const newSalt = crypto.getRandomValues(new Uint8Array(16)).buffer as ArrayBuffer;
    const newKdf = makeKdfMeta(newSalt);
    const newKek = await deriveKEK(newPassword, newSalt);
    const newWrapped = await wrapDEK(dek, newKek);
    const newVerifier = await makeVerifier(newKek);

    await metaSet('kdf', newKdf);
    await metaSet('verifier', newVerifier);
    await metaSet('wrappedDek', newWrapped);

    set({ kdf: newKdf, verifier: newVerifier, wrappedDek: newWrapped, error: null });
    return true;
  },

  destroy: async () => {
    await wipeAll();
    set({ status: 'uninitialized', dek: null, kdf: null, verifier: null, wrappedDek: null });
  },

  exportBackup: async () => {
    return doExport();
  },

  importBackup: async (data, backupPassword) => {
    const result = await doImport(data, backupPassword);
    set({
      status: 'unlocked',
      dek: result.dek,
      kdf: result.kdf,
      verifier: result.verifier,
      wrappedDek: result.wrappedDek,
      error: null,
    });
  },
}));
