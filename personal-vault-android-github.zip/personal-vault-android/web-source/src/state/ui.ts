import { create } from 'zustand';

export interface Toast {
  id: string;
  kind: 'success' | 'error' | 'info';
  message: string;
  action?: { label: string; onClick: () => void };
}

interface UIState {
  toasts: Toast[];
  pushToast: (t: Omit<Toast, 'id'>) => string;
  dismissToast: (id: string) => void;
}

export const useUI = create<UIState>((set) => ({
  toasts: [],
  pushToast: (t) => {
    const id = Math.random().toString(36).slice(2);
    set((s) => ({ toasts: [...s.toasts, { ...t, id }] }));
    setTimeout(() => {
      set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) }));
    }, t.action ? 6000 : 3500);
    return id;
  },
  dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })),
}));

export function toast(message: string, kind: Toast['kind'] = 'info', action?: Toast['action']) {
  return useUI.getState().pushToast({ message, kind, action });
}
