import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { getDB } from '../core/db';
import { Button } from '../ui/primitives';
import { IconLock, IconFolder, IconImage, IconText, IconTrash } from '../ui/icons';
import '../styles/tokens.css';
import '../styles/global.css';

function Popup() {
  const [counts, setCounts] = useState({ files: 0, images: 0, texts: 0, trash: 0 });
  const [hasVault, setHasVault] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const db = await getDB();
        const [kdf, items] = await Promise.all([
          db.get('meta', 'kdf'),
          db.getAll('items'),
        ]);
        setHasVault(!!kdf);
        setCounts({
          files:  items.filter((i) => i.type === 'file'  && i.deletedAt === 0).length,
          images: items.filter((i) => i.type === 'image' && i.deletedAt === 0).length,
          texts:  items.filter((i) => i.type === 'text'  && i.deletedAt === 0).length,
          trash:  items.filter((i) => i.deletedAt !== 0).length,
        });
      } catch { setHasVault(false); }
      finally { setLoading(false); }
    })();
  }, []);

  function openApp() {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/app/index.html') });
    window.close();
  }

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
        <span className="spinner" />
      </div>
    );
  }

  return (
    <div style={{ padding: 16, height: '100%', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--surface)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)' }}>
          <IconLock width={18} height={18} />
        </div>
        <div>
          <div style={{ fontWeight: 600 }}>Personal Vault</div>
          <div style={{ fontSize: 12, color: 'var(--fg-muted)' }}>
            {hasVault ? 'Encrypted · local-only' : 'Not yet configured'}
          </div>
        </div>
      </div>

      {hasVault && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, fontSize: 12 }}>
          <div style={{ textAlign: 'center', padding: 8, background: 'var(--surface)', borderRadius: 8 }}>
            <IconFolder width={16} height={16} />
            <div style={{ fontWeight: 600, marginTop: 4 }}>{counts.files}</div>
            <div style={{ color: 'var(--fg-muted)' }}>Files</div>
          </div>
          <div style={{ textAlign: 'center', padding: 8, background: 'var(--surface)', borderRadius: 8 }}>
            <IconImage width={16} height={16} />
            <div style={{ fontWeight: 600, marginTop: 4 }}>{counts.images}</div>
            <div style={{ color: 'var(--fg-muted)' }}>Images</div>
          </div>
          <div style={{ textAlign: 'center', padding: 8, background: 'var(--surface)', borderRadius: 8 }}>
            <IconText width={16} height={16} />
            <div style={{ fontWeight: 600, marginTop: 4 }}>{counts.texts}</div>
            <div style={{ color: 'var(--fg-muted)' }}>Texts</div>
          </div>
        </div>
      )}

      <div style={{ flex: 1 }} />
      <Button variant="primary" onClick={openApp} style={{ width: '100%' }}>
        {hasVault ? 'Open Vault' : 'Set up Vault'}
      </Button>

      {counts.trash > 0 && (
        <div style={{ fontSize: 11, color: 'var(--fg-muted)', textAlign: 'center' }}>
          <IconTrash width={12} height={12} /> {counts.trash} item{counts.trash === 1 ? '' : 's'} in Trash
        </div>
      )}
    </div>
  );
}

const container = document.getElementById('root');
if (!container) throw new Error('Root missing');
createRoot(container).render(<React.StrictMode><Popup /></React.StrictMode>);
