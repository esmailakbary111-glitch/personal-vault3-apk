$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$android = Join-Path $root 'android'
if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
  Write-Host 'Gradle was not found in PATH.' -ForegroundColor Yellow
  Write-Host 'For phone-only build, upload this project to GitHub and run the Build Personal Vault APK workflow.'
  exit 1
}
Set-Location $android
gradle --version
gradle --no-daemon :app:assembleDebug
Write-Host "`nAPK: $android\app\build\outputs\apk\debug\app-debug.apk" -ForegroundColor Green
