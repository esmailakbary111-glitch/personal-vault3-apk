package com.personalvault.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.CookieManager;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.IOException;

public final class MainActivity extends Activity {
    private static final int CREATE_FILE = 4101;
    private static final int PICK_FILE = 4102;

    private WebView webView;
    private AssetHttpServer server;
    private ValueCallback<Uri[]> pendingChooser;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("http://127.0.0.1:27843/");
            }
        });
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingChooser != null) pendingChooser.onReceiveValue(null);
                pendingChooser = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                startActivityForResult(intent, PICK_FILE);
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        try {
            server = new AssetHttpServer(this);
            int port = server.start();
            webView.loadUrl("http://127.0.0.1:" + port + "/index.html");
        } catch (IOException e) {
            Toast.makeText(this, "Unable to start Personal Vault", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingChooser != null) pendingChooser.onReceiveValue(null);
        if (server != null) server.stop();
        webView.removeJavascriptInterface("AndroidBridge");
        webView.destroy();
        super.onDestroy();
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveFile(String filename, String mimeType, String base64) {
            try {
                pendingSaveBytes = Base64.decode(base64, Base64.DEFAULT);
                pendingSaveMime = mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingSaveMime);
                intent.putExtra(Intent.EXTRA_TITLE, filename == null ? "download" : filename);
                startActivityForResult(intent, CREATE_FILE);
            } catch (IllegalArgumentException e) {
                Toast.makeText(MainActivity.this, "Could not prepare file", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            ValueCallback<Uri[]> callback = pendingChooser;
            pendingChooser = null;
            if (callback == null) return;
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                callback.onReceiveValue(null);
                return;
            }
            callback.onReceiveValue(new Uri[]{data.getData()});
            return;
        }

        if (requestCode == CREATE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IOException("Cannot open destination");
                    out.write(pendingSaveBytes);
                    out.flush();
                    Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveBytes = null;
            pendingSaveMime = null;
        }
    }
}
