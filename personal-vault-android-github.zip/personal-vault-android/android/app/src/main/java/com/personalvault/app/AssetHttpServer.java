package com.personalvault.app;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

final class AssetHttpServer {
    private final Context context;
    private ServerSocket serverSocket;
    private Thread thread;
    private volatile boolean running;
    private static final int PORT = 27843;
    private int port;

    AssetHttpServer(Context context) {
        this.context = context.getApplicationContext();
    }

    int start() throws IOException {
        if (running) return port;
        serverSocket = new ServerSocket(PORT, 32, java.net.InetAddress.getByName("127.0.0.1"));
        port = PORT;
        running = true;
        thread = new Thread(this::loop, "pv-asset-server");
        thread.start();
        return port;
    }

    void stop() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (IOException ignored) { }
    }

    private void loop() {
        while (running) {
            try {
                Socket socket = serverSocket.accept();
                Thread t = new Thread(() -> handle(socket), "pv-http-client");
                t.start();
            } catch (IOException ignored) {
                if (!running) return;
            }
        }
    }

    private void handle(Socket socket) {
        try (Socket s = socket) {
            s.setSoTimeout(5000);
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();
            ByteArrayOutputStream request = new ByteArrayOutputStream();
            int previous = -1, current;
            while ((current = in.read()) != -1) {
                request.write(current);
                if (previous == '\r' && current == '\n') {
                    byte[] data = request.toByteArray();
                    int n = data.length;
                    if (n >= 4 && data[n - 4] == '\r' && data[n - 3] == '\n' && data[n - 2] == '\r' && data[n - 1] == '\n') break;
                }
                previous = current;
                if (request.size() > 8192) return;
            }

            String text = request.toString(StandardCharsets.US_ASCII);
            String[] lines = text.split("\\r\\n");
            if (lines.length == 0) return;
            String[] parts = lines[0].split(" ");
            if (parts.length < 2 || !"GET".equals(parts[0])) {
                writeResponse(out, 405, "text/plain; charset=utf-8", "Method Not Allowed".getBytes(StandardCharsets.UTF_8));
                return;
            }

            String path = parts[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            if (path.equals("/") || path.isEmpty()) path = "/index.html";
            if (path.contains("..") || path.contains("\\")) {
                writeResponse(out, 403, "text/plain; charset=utf-8", "Forbidden".getBytes(StandardCharsets.UTF_8));
                return;
            }

            String assetPath = path.substring(1);
            byte[] bytes;
            try (InputStream asset = context.getAssets().open(assetPath)) {
                bytes = readAll(asset);
            } catch (IOException e) {
                writeResponse(out, 404, "text/plain; charset=utf-8", "Not Found".getBytes(StandardCharsets.UTF_8));
                return;
            }

            writeResponse(out, 200, mime(assetPath), bytes);
        } catch (IOException ignored) {
            // Client disconnected or timed out.
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private static String mime(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html; charset=utf-8";
        if (p.endsWith(".js")) return "text/javascript; charset=utf-8";
        if (p.endsWith(".css")) return "text/css; charset=utf-8";
        if (p.endsWith(".json")) return "application/json; charset=utf-8";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }

    private static void writeResponse(OutputStream out, int status, String mime, byte[] body) throws IOException {
        String reason = status == 200 ? "OK" : status == 403 ? "Forbidden" : status == 404 ? "Not Found" : "Method Not Allowed";
        String headers = "HTTP/1.1 " + status + " " + reason + "\r\n" +
                "Content-Type: " + mime + "\r\n" +
                "Content-Length: " + body.length + "\r\n" +
                "Cache-Control: no-store\r\n" +
                "Connection: close\r\n\r\n";
        out.write(headers.getBytes(StandardCharsets.US_ASCII));
        out.write(body);
        out.flush();
    }
}
