# Personal Vault — Android

این پوشه نسخهٔ Android مستقل پروژهٔ Personal Vault است. هدف این نسخه اجرای Vault روی گوشی اندرویدی بدون نیاز به Chrome Extension است.

## امکانات

- AES-GCM 256 برای رمزگذاری داده‌ها
- PBKDF2-SHA-256 با 600,000 iteration
- DEK مستقل و Wrapped DEK
- ذخیرهٔ محلی با IndexedDB
- فایل، تصویر و متن
- جستجو و مرتب‌سازی
- Trash با Soft Delete و بازیابی
- حذف دائمی
- تغییر رمز عبور
- Auto-Lock قابل تنظیم از 5 تا 60 دقیقه
- Backup/Restore به فرمت ZIP
- ذخیرهٔ فایل و Backup از طریق Android Storage Access Framework
- اجرای کاملاً محلی؛ اپ فایل یا API خارجی لازم ندارد

## ساخت APK در Windows 11

1. Android Studio نسخهٔ Stable را نصب کنید.
2. Android Studio را باز کنید و فولدر `android/` همین پروژه را به‌عنوان Gradle Project باز کنید.
3. اجازه دهید Gradle و Android SDK موردنیاز دانلود شوند.
4. از منوی Build گزینهٔ `Build APK(s)` را اجرا کنید.
5. خروجی Debug در مسیر زیر خواهد بود:

`android/app/build/outputs/apk/debug/app-debug.apk`

### مشخصات Build

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- JDK: 17 یا بالاتر
- compileSdk: 36
- targetSdk: 36
- minSdk: 26

نسخه‌های انتخاب‌شده با وضعیت فعلی ابزار Android هماهنگ هستند؛ AGP 9.4.0 به Gradle 9.6.0 و JDK حداقل 17 نیاز دارد.

## نکتهٔ امنیتی

این برنامه Local-first است. رمز عبور و دادهٔ خام فایل در IndexedDB ذخیره نمی‌شوند. کلید DEK در حافظهٔ اجرای صفحه نگه داشته می‌شود و با Lock از state جاوااسکریپت حذف می‌شود.

Backup حاوی داده‌هایی است که در خود Vault رمزگذاری شده‌اند و به‌صورت ZIP ذخیره می‌شود. برای فایل‌های حجیم، Backup می‌تواند مصرف RAM قابل‌توجهی داشته باشد.

## سورس Chrome

فولدر `web-source/` همان سورس افزونهٔ Chrome ارسالی است و برای مقایسه و توسعهٔ نسخهٔ Extension نگهداری شده است.

## ساخت APK بدون کامپیوتر

برای ساخت APK فقط با گوشی، فایل `.github/workflows/build-apk.yml` را همراه کل پروژه به GitHub منتقل کنید و Workflow با نام `Build Personal Vault APK` را از بخش Actions اجرا کنید. سپس Artifact با نام `personal-vault-apk` را دانلود کنید.
