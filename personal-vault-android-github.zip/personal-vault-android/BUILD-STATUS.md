# Build status in the current execution environment

The Android source project was created and statically checked. The current execution environment does not contain Android SDK, Gradle, aapt2, d8, or apksigner, and external downloads are unavailable, so a real APK binary could not be produced here.

JavaScript syntax check: PASS (`node --check android/app/src/main/assets/app.js`).

For a real APK, open `android/` in Android Studio Stable and build `assembleDebug`. The resulting APK is `android/app/build/outputs/apk/debug/app-debug.apk`.
